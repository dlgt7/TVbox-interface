var _0xodA = 'jsjiami.com.v6',
    _0xodA_ = ['‮_0xodA'],
    _0x4a07 = [_0xodA, 'bjzDgm4t', 'w40Twq5Swq4=', 'w6vDtMKOcMKg', 'w67CjlvChsKVYAkywr4zwpnDknBxfUrDosOtQTnCtMORwonDtcKLOAjDm07DolrCmMOyZsOFSjk=', 'wqXCiUPChg==', 'ZcKRwpLDiEAZw7IZwoZra8On', 'wofCnMKqwqc2', 'X8Oawq5ZDQ==', 'w5EpwqPDsAo=', 'w5J0Dx0=', 'w59ZAw==', 'FWvDrsKJ', 'w63DhW5rQA==', 'acOmwqkjCU4=', 'acOmwr8VAg==', 'dsOUb8K6fw==', 'cMOuM8KJwpoq', 'wpzCpyXCpyA=', 'dC3Cn8OB', 'csKYwpjDmVw=', 'w5l7AQ==', 'XMOLwqZ1F8Km', 'wo/CvMO9HA==', 'SiXDt2oIw6PCi8K+w4o=', 'F8K5LQ==', 'bsOpNj/Ctg==', 'wr9uwrg=', 'SgJEw4sHwp4=', 'GCjDlHs8w4EzHCg=', 'wqPCkXo=', 'w7JSGA==', 'woTDlWILwpQ=', 'w7vDj8OCwqpVFMOZRsOO', 'w7zDlm55XMKOGQVEIRk=', 'w7cew6o=', 'w7XDisK6LQ==', 'w6bDjDfDmRA=', 'w585Pg==', 'O8K5NkoNUMOu', 'KsKZXMO9', 'w7jDm8OE', 'w43Dj39rEg==', 'OB8Ew5IFw5bCrsK7w4E=', 'wr7DvHE6wqg=', 'w7zDlGx0XA==', 'DMKfXMOSIg==', 'fCzDg8Kpw6TCnUVYwpfCl8OsNHXCicKHbnh+woN5w40wIzkow50sVRbCmE5KJzvDuUl7w4nDtMOiw63DrsKdBg3DtcKJwr3CtsOi', 'w4TDmMOjwqxG', 'OxvDhkk6', 'dsKSwp7Do3c=', 'PylHwoUeckHCkcOe', 'CRQgw6Aw', 'wrPDtkAwwpQ=', 'NcKTSMO0IQPDpQ==', 'w7vDs8KGWcKOM8KrwoLDsWI9cMO0wrHCs8OLbWhvw64pw6fCrsKNwp/ChsKJCR/DjMKOZcOLM8OOLg==', 'wrNJEsOZwo8=', 'BVgyO14=', 'FhvDrEk0', 'SCjDjMOkwrU=', 'w7g6K8Kuw7U=', 'w6IfwrTDsCo=', 'w5IgwrRywqw=', 'EQzDmiIPwoA=', 'X8OEwoQuDg==', 'w7IZA8KOw6nDpw==', 'LR/Dr1o7', 'YsK7woLDu3s=', 'cTzClMOLwoLDhg==', 'w5YoJ8KFw5o=', 'wqxcEMOXwo/Dgg==', 'w5BwDB/ChsON', 'w5ZSDsKvwrXDrQ==', 'wrPCpsO/QcKQwrtj', 'TsO+UMKOfA==', 'FsKvTsO0JQ==', 'w5wGwoVNwqM=', 'w7TDinh9XcKDCg==', 'wohcBsOHwp0=', 'QcK4PH7DocK2V8O1wpY=', 'w58KwpVjwo8=', 'KC8pXsOa', 'w7IKwpFfwrY=', 'XsK1SVg=', 'w7FGw5LCvgTDiETDtsKHwqbCug==', 'a8K2wrrDlU0=', 'w67DkX5rUcK+BQ1F', 'UxPDjmwS', 'WiVZw7l5', 'Ux3DlsOMwq8=', 'TnvDt8KcI8KQX0/Cqw==', 'TBTDksOowrY=', 'w6cTwpFTwrE=', 'HgHDlTc4wocEw6fCkMKv', 'w4HDisKzdw==', 'bcO9Jj/Cp8O1XcKjw4M=', 'aMOuMsKawrYwNcOBwrFqcA==', 'N8Otwr0B', 'wq7CkxjCncOBJQ==', 'AijDg38=', 'w7JuwrlYw6w=', 'w5YEwqDDmg==', 'L8KwYwgcwr1Vw58dI8OX', 'w5dzwr5J', 'CVM2O2snN8OfBMO9wpk=', 'XT7Dq2Y=', 'wo7CmiHCnMOP', 'w4cMPsKBw7Y=', 'w5/DjsO6wqlM', 'OW4NPWQ=', 'EFDDocOhSw==', 'jTHsrCXCdjOifWami.cwomtZ.vk6R=='];
if (function(_0x18eb0c, _0x25218e, _0x3a5f21) {
    function _0x28e112(_0x4ed294, _0x3acf20, _0x13a097, _0x5c4d1f, _0x8ba739, _0xc54c76) {
        _0x3acf20 = _0x3acf20 >> 0x8, _0x8ba739 = 'po';
        var _0x1e8a1b = 'shift',
            _0x2536b5 = 'push',
            _0xc54c76 = '‮';
        if (_0x3acf20 < _0x4ed294) {
            while (--_0x4ed294) {
                _0x5c4d1f = _0x18eb0c[_0x1e8a1b]();
                if (_0x3acf20 === _0x4ed294 && _0xc54c76 === '‮' && _0xc54c76['length'] === 0x1) {
                    _0x3acf20 = _0x5c4d1f, _0x13a097 = _0x18eb0c[_0x8ba739 + 'p']();
                } else if (_0x3acf20 && _0x13a097['replace'](/[THrCXCdOfWwtZkR=]/g, '') === _0x3acf20) {
                    _0x18eb0c[_0x2536b5](_0x5c4d1f);
                }
            }
            _0x18eb0c[_0x2536b5](_0x18eb0c[_0x1e8a1b]());
        }
        return 0xe15d7;
    };
    return _0x28e112(++_0x25218e, _0x3a5f21) >> _0x25218e ^ _0x3a5f21;
}(_0x4a07, 0x98, 0x9800), _0x4a07) {
    _0xodA_ = _0x4a07['length'] ^ 0x98;
};

function _0x3084(_0x28be4f, _0x52a57d) {
    _0x28be4f = ~~'0x' ['concat'](_0x28be4f['slice'](0x1));
    var _0x42bc0c = _0x4a07[_0x28be4f];
    if (_0x3084['cpzEDL'] === undefined) {
        (function() {
            var _0xeba711 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0x29567c = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0xeba711['atob'] || (_0xeba711['atob'] = function(_0x5ec340) {
                var _0x477c4b = String(_0x5ec340)['replace'](/=+$/, '');
                for (var _0x51ce42 = 0x0, _0x45feaf, _0x5b490d, _0x58eab3 = 0x0, _0x404e9f = ''; _0x5b490d = _0x477c4b['charAt'](_0x58eab3++); ~_0x5b490d && (_0x45feaf = _0x51ce42 % 0x4 ? _0x45feaf * 0x40 + _0x5b490d : _0x5b490d, _0x51ce42++ % 0x4) ? _0x404e9f += String['fromCharCode'](0xff & _0x45feaf >> (-0x2 * _0x51ce42 & 0x6)) : 0x0) {
                    _0x5b490d = _0x29567c['indexOf'](_0x5b490d);
                }
                return _0x404e9f;
            });
        }());

        function _0x3b8d05(_0x1d6539, _0x52a57d) {
            var _0x4cd97b = [],
                _0x50a4b0 = 0x0,
                _0x5a4e2c, _0x4a5854 = '',
                _0x3f0335 = '';
            _0x1d6539 = atob(_0x1d6539);
            for (var _0x2b23c8 = 0x0, _0x181cbe = _0x1d6539['length']; _0x2b23c8 < _0x181cbe; _0x2b23c8++) {
                _0x3f0335 += '%' + ('00' + _0x1d6539['charCodeAt'](_0x2b23c8)['toString'](0x10))['slice'](-0x2);
            }
            _0x1d6539 = decodeURIComponent(_0x3f0335);
            for (var _0x5bc16d = 0x0; _0x5bc16d < 0x100; _0x5bc16d++) {
                _0x4cd97b[_0x5bc16d] = _0x5bc16d;
            }
            for (_0x5bc16d = 0x0; _0x5bc16d < 0x100; _0x5bc16d++) {
                _0x50a4b0 = (_0x50a4b0 + _0x4cd97b[_0x5bc16d] + _0x52a57d['charCodeAt'](_0x5bc16d % _0x52a57d['length'])) % 0x100;
                _0x5a4e2c = _0x4cd97b[_0x5bc16d];
                _0x4cd97b[_0x5bc16d] = _0x4cd97b[_0x50a4b0];
                _0x4cd97b[_0x50a4b0] = _0x5a4e2c;
            }
            _0x5bc16d = 0x0;
            _0x50a4b0 = 0x0;
            for (var _0x4265e8 = 0x0; _0x4265e8 < _0x1d6539['length']; _0x4265e8++) {
                _0x5bc16d = (_0x5bc16d + 0x1) % 0x100;
                _0x50a4b0 = (_0x50a4b0 + _0x4cd97b[_0x5bc16d]) % 0x100;
                _0x5a4e2c = _0x4cd97b[_0x5bc16d];
                _0x4cd97b[_0x5bc16d] = _0x4cd97b[_0x50a4b0];
                _0x4cd97b[_0x50a4b0] = _0x5a4e2c;
                _0x4a5854 += String['fromCharCode'](_0x1d6539['charCodeAt'](_0x4265e8) ^ _0x4cd97b[(_0x4cd97b[_0x5bc16d] + _0x4cd97b[_0x50a4b0]) % 0x100]);
            }
            return _0x4a5854;
        }
        _0x3084['GnNnDG'] = _0x3b8d05;
        _0x3084['QDBoxR'] = {};
        _0x3084['cpzEDL'] = !![];
    }
    var _0x14500f = _0x3084['QDBoxR'][_0x28be4f];
    if (_0x14500f === undefined) {
        if (_0x3084['SyKjYB'] === undefined) {
            _0x3084['SyKjYB'] = !![];
        }
        _0x42bc0c = _0x3084['GnNnDG'](_0x42bc0c, _0x52a57d);
        _0x3084['QDBoxR'][_0x28be4f] = _0x42bc0c;
    } else {
        _0x42bc0c = _0x14500f;
    }
    return _0x42bc0c;
};
var _0x9c9a16 = function(_0x1a4243) {
    var _0x5cd4f5 = {
        'JHaBY': function(_0x4242df, _0x5d3d3e) {
            return _0x4242df === _0x5d3d3e;
        }
    };
    var _0x5aa680 = !![];
    return function(_0x24c54a, _0x38342) {
        var _0x389bb3 = _0x3084('‮0', 'iQj4')['split']('|'),
            _0xf6b1a3 = 0x0;
        while (!![]) {
            switch (_0x389bb3[_0xf6b1a3++]) {
                case '0':
                    var _0x106dcd = '‮';
                    continue;
                case '1':
                    return _0x2780c4;
                case '2':
                    var _0x1a4243 = '‮';
                    continue;
                case '3':
                    var _0x2780c4 = _0x5aa680 ? function() {
                        if (_0x5cd4f5[_0x3084('‮1', 'ZWyl')](_0x106dcd, '‮') && _0x38342) {
                            var _0x549c3c = _0x38342[_0x3084('‫2', 'O(uL')](_0x24c54a, arguments);
                            _0x38342 = null;
                            return _0x549c3c;
                        }
                    } : function(_0x1a4243) {};
                    continue;
                case '4':
                    _0x5aa680 = ![];
                    continue;
            }
            break;
        }
    };
}();
var _0x221c82 = _0x9c9a16(this, function() {
    var _0x292c82 = {
        'cOsAB': function(_0x57cc46, _0x29384c) {
            return _0x57cc46 == _0x29384c;
        },
        'myvaL': _0x3084('‫3', 'PZ)Q'),
        'wfoYN': function(_0x595218, _0x2f3bd7) {
            return _0x595218 !== _0x2f3bd7;
        },
        'Kcvvb': 'object',
        'gVxgh': function(_0x33863a, _0x32feba) {
            return _0x33863a === _0x32feba;
        },
        'xmiWq': 'function',
        'GBPHe': _0x3084('‮4', '9UeV'),
        'fFFGh': function(_0x56781d, _0x5adec1) {
            return _0x56781d === _0x5adec1;
        },
        'ZzyOF': _0x3084('‫5', '[r3y'),
        'vUrmN': _0x3084('‫6', '3k4@'),
        'FCIHi': function(_0x458717, _0x3f5c3f) {
            return _0x458717 === _0x3f5c3f;
        },
        'HTJlG': function(_0x1d7b0a, _0x1881ec) {
            return _0x1d7b0a < _0x1881ec;
        },
        'GYDvv': function(_0x166d0e, _0x4b5582) {
            return _0x166d0e - _0x4b5582;
        },
        'KFVWf': function(_0x62584, _0x43d3d7) {
            return _0x62584 === _0x43d3d7;
        },
        'QYvle': function(_0x1aefb9, _0x1793ac) {
            return _0x1aefb9 == _0x1793ac;
        },
        'Hexwf': function(_0x221de1, _0x139f1c) {
            return _0x221de1 === _0x139f1c;
        },
        'hnMRY': function(_0x69d7b, _0x19cd8c) {
            return _0x69d7b !== _0x19cd8c;
        },
        'KihYJ': function(_0x44601a) {
            return _0x44601a();
        }
    };
    var _0x299481 = '‮';
    var _0x11e19a = _0x292c82[_0x3084('‫7', 'Ba8C')](typeof window, _0x3084('‮8', 'k]14')) ? window : typeof process === _0x292c82['Kcvvb'] && _0x292c82[_0x3084('‮9', 'EvW7')](typeof require, _0x292c82['xmiWq']) && typeof global === 'object' ? global : this;
    var _0x56eb01 = [
        [0x0, 0x0, 0x0, 0x0, 0x0],
        [_0x292c82[_0x3084('‫a', 'ZWyl')][_0x3084('‮b', 'PZ)Q')](new RegExp(_0x3084('‫c', 'Yj]*'), 'g'), '')[_0x3084('‫d', 'DqP(')](';'), ![]],
        [
            function(_0x4b6c5e, _0x291b5a, _0x530e6a) {
                return _0x292c82['cOsAB'](_0x4b6c5e['charCodeAt'](_0x291b5a), _0x530e6a);
            },
            function(_0x14ef7a, _0xd8d0f4, _0x199c78) {
                if (_0x292c82[_0x3084('‮e', 'kAHO')] !== _0x3084('‫f', '3k4@')) {
                    _0x56eb01[_0x14ef7a][_0xd8d0f4] = _0x199c78;
                } else {
                    _0x56eb01[0x2][0x1](0x0, 0x4, _0x58b99e);
                }
            },
            function() {
                return !0x0;
            }
        ]
    ];
    var _0x10e59d = function() {
        while (_0x56eb01[0x2][0x2]()) {
            _0x11e19a[_0x56eb01[0x0][0x0]][_0x56eb01[0x0][0x2]][_0x56eb01[0x0][0x4]] = _0x11e19a[_0x56eb01[0x0][0x0]][_0x56eb01[0x0][0x2]][_0x56eb01[0x0][0x4]];
        };
    };
    for (var _0x29d707 in _0x11e19a) {
        if (_0x292c82['gVxgh'](_0x299481, '‮') && _0x292c82[_0x3084('‫10', 'P%wZ')](_0x29d707['length'], 0x8) && _0x56eb01[0x2][0x0](_0x29d707, 0x7, 0x74) && _0x56eb01[0x2][0x0](_0x29d707, 0x5, 0x65) && _0x56eb01[0x2][0x0](_0x29d707, 0x3, 0x75) && _0x56eb01[0x2][0x0](_0x29d707, 0x0, 0x64)) {
            if (_0x292c82[_0x3084('‫11', '@MU(')](_0x292c82[_0x3084('‮12', '%V[U')], _0x292c82['vUrmN'])) {
                var _0x5aa6c1 = fn['apply'](context, arguments);
                fn = null;
                return _0x5aa6c1;
            } else {
                _0x56eb01[0x2][0x1](0x0, 0x0, _0x29d707);
                break;
            }
        }
    }
    for (var _0x3b75a7 in _0x11e19a[_0x56eb01[0x0][0x0]]) {
        if (_0x292c82[_0x3084('‫13', '*g@m')](_0x299481, '‮') && _0x3b75a7['length'] == 0x6 && _0x56eb01[0x2][0x0](_0x3b75a7, 0x5, 0x6e) && _0x56eb01[0x2][0x0](_0x3b75a7, 0x0, 0x64)) {
            _0x56eb01[0x2][0x1](0x0, 0x1, _0x3b75a7);
            break;
        }
    }
    for (var _0x19100a in _0x11e19a[_0x56eb01[0x0][0x0]]) {
        if (_0x299481 === '‮' && _0x19100a[_0x3084('‮14', '21IK')] == 0x8 && _0x56eb01[0x2][0x0](_0x19100a, 0x7, 0x6e) && _0x56eb01[0x2][0x0](_0x19100a, 0x0, 0x6c)) {
            _0x56eb01[0x2][0x1](0x0, 0x2, _0x19100a);
            break;
        }
    }
    for (var _0x58b99e in _0x11e19a[_0x56eb01[0x0][0x0]][_0x56eb01[0x0][0x2]]) {
        if (_0x292c82[_0x3084('‫15', '58bt')](_0x299481, '‮') && _0x58b99e[_0x3084('‫16', '@MU(')] == 0x4 && _0x56eb01[0x2][0x0](_0x58b99e, 0x3, 0x66)) {
            _0x56eb01[0x2][0x1](0x0, 0x4, _0x58b99e);
        } else if (_0x292c82[_0x3084('‮17', 'AOZ*')](_0x299481, '‮') && _0x292c82[_0x3084('‮18', 'Ba8C')](_0x58b99e[_0x3084('‮19', 'CynS')], 0x8) && _0x56eb01[0x2][0x0](_0x58b99e, 0x7, 0x65) && _0x56eb01[0x2][0x0](_0x58b99e, 0x0, 0x68)) {
            _0x56eb01[0x2][0x1](0x0, 0x3, _0x58b99e);
        }
    }
    if (!_0x56eb01[0x0][0x0] || !_0x11e19a[_0x56eb01[0x0][0x0]]) {
        return;
    }
    var _0x50b1be = _0x11e19a[_0x56eb01[0x0][0x0]][_0x56eb01[0x0][0x1]];
    var _0x1581d4 = !!_0x11e19a[_0x56eb01[0x0][0x0]][_0x56eb01[0x0][0x2]] && _0x11e19a[_0x56eb01[0x0][0x0]][_0x56eb01[0x0][0x2]][_0x56eb01[0x0][0x3]];
    var _0x4788f4 = _0x50b1be || _0x1581d4;
    if (!_0x4788f4) {
        return;
    }
    _0x5c87de: for (var _0x16ab7b = 0x0; _0x292c82[_0x3084('‮1a', '@MU(')](_0x16ab7b, _0x56eb01[0x1][0x0][_0x3084('‫1b', 'DqP(')]); _0x16ab7b++) {
        var _0x3bdc5d = _0x56eb01[0x1][0x0][_0x16ab7b];
        var _0x5c2d06 = _0x292c82['GYDvv'](_0x4788f4[_0x3084('‮1c', 'WErh')], _0x3bdc5d[_0x3084('‮1d', 'Ugcw')]);
        var _0x90b57e = _0x4788f4[_0x3084('‮1e', 'Hw2W')](_0x3bdc5d, _0x5c2d06);
        var _0xf35daf = _0x292c82['wfoYN'](_0x90b57e, -0x1) && _0x292c82[_0x3084('‫1f', 'sCFv')](_0x90b57e, _0x5c2d06);
        if (_0xf35daf) {
            if (_0x292c82[_0x3084('‫20', 'PZ)Q')](_0x4788f4[_0x3084('‫16', '@MU(')], _0x3bdc5d['length']) || _0x292c82[_0x3084('‫21', '*g@m')](_0x3bdc5d[_0x3084('‫22', 'O(uL')]('.'), 0x0)) {
                _0x56eb01[0x1][0x0] = '_0x221c82';
                break _0x5c87de;
            }
        }
    }
    if (_0x292c82[_0x3084('‫23', 'DqP(')](_0x299481, '‮') && _0x292c82['hnMRY'](_0x56eb01[0x1][0x0], _0x3084('‫24', 'B#(0'))) {
        //_0x292c82[_0x3084('‫25', '*g@m')](_0x10e59d);
    }
});
_0x221c82();
async function imgToStr(_0x36fc00) {
    var _0x1e7278 = {
        'jBKot': function(_0x218ef3, _0x1eb1a6) {
            return _0x218ef3(_0x1eb1a6);
        },
        'MmEUK': function(_0x679e15, _0x4e8360) {
            return _0x679e15 + _0x4e8360;
        },
        'RFnWH': function(_0xa74143, _0x2936d6, _0x149a67) {
            return _0xa74143(_0x2936d6, _0x149a67);
        },
        'xziiX': _0x3084('‮26', 'rx4M')
    };
    const _0x310797 = _0x36fc00['target'][_0x3084('‮27', '*g@m')]['item'](0x0);
    const _0x1ee7ca = _0x1e7278['jBKot'](getFileName, _0x310797[_0x3084('‮28', 'FVxx')]);
    const _0x5118ac = await _0x310797[_0x3084('‮29', 'W19j')]();
    var _0x3349bc = _0x1e7278[_0x3084('‮2a', 'Ba8C')](ab2Str, _0x5118ac);
    var _0x1cf069 = _0x3349bc['lastIndexOf']('**');
    _0x3349bc = _0x3349bc[_0x3084('‫2b', 'O(uL')](_0x1e7278['MmEUK'](_0x1cf069, 0x2));
    _0x3349bc = _0x1e7278[_0x3084('‮2c', 'AMID')](base64ToAb, _0x3349bc);
    _0x1e7278[_0x3084('‫2d', 'iQj4')](downloadFile, _0x1ee7ca + _0x1e7278[_0x3084('‮2e', 'P%wZ')], _0x3349bc);
}

function base64ToAb(_0x5887b0) {
    var _0x5583d2 = {
        'gsmMA': _0x3084('‮2f', '$lS^'),
        'bGAGC': function(_0x36bc9f, _0x345f93) {
            return _0x36bc9f < _0x345f93;
        }
    };
    var _0x11c56e = _0x5583d2[_0x3084('‫30', 'P%wZ')][_0x3084('‫31', '*g@m')]('|'),
        _0x1190bb = 0x0;
    while (!![]) {
        switch (_0x11c56e[_0x1190bb++]) {
            case '0':
                return _0x1619fa['buffer'];
            case '1':
                var _0x1619fa = new Uint8Array(_0x499346);
                continue;
            case '2':
                for (var _0x513bf4 = 0x0; _0x5583d2['bGAGC'](_0x513bf4, _0x499346); _0x513bf4++) {
                    _0x1619fa[_0x513bf4] = _0x57d370[_0x3084('‫32', '21IK')](_0x513bf4);
                }
                continue;
            case '3':
                var _0x499346 = _0x57d370[_0x3084('‮1c', 'WErh')];
                continue;
            case '4':
                var _0x57d370 = window[_0x3084('‫33', 'Yj]*')](_0x5887b0);
                continue;
        }
        break;
    }
}

function getFileName(_0x5e5feb) {
    return _0x5e5feb[_0x3084('‫34', 'B#(0')](0x0, _0x5e5feb[_0x3084('‫35', 'dDml')]('.'));
}
async function toImg2(_0x5d3024) {
    var _0x1fea60 = {
        'ThKfk': function(_0x43a4bc, _0xf2c99d) {
            return _0x43a4bc(_0xf2c99d);
        },
        'YpShk': function(_0x4c189e, _0xd00a32) {
            return _0x4c189e + _0xd00a32;
        },
        'WtZpm': function(_0x5aa29e, _0x4831d4) {
            return _0x5aa29e(_0x4831d4);
        },
        'QOIgv': function(_0x4d1dea, _0x141ca9) {
            return _0x4d1dea(_0x141ca9);
        },
        'POiPQ': function(_0x1771ee, _0x265e85, _0x3f91fc, _0x2b6ada) {
            return _0x1771ee(_0x265e85, _0x3f91fc, _0x2b6ada);
        },
        'WmGmK': function(_0x132f79, _0x2364d0, _0x4f5bed) {
            return _0x132f79(_0x2364d0, _0x4f5bed);
        },
        'KJRew': _0x3084('‮36', '58bt'),
        'DwfiS': function(_0x249bfa, _0x24d5bd) {
            return _0x249bfa(_0x24d5bd);
        }
    };
    const _0x18f43e = _0x5d3024[_0x3084('‫37', ']XO^')]['files'][_0x3084('‫38', 'AOZ*')](0x0);
    const _0x5f7583 = _0x1fea60[_0x3084('‮39', '7BVq')](getFileName, _0x18f43e[_0x3084('‫3a', '%V[U')]);
    const _0x31d96a = await _0x18f43e[_0x3084('‮3b', 'tLEK')]();
    $[_0x3084('‫3c', '7BVq')]({
        'url': './static/cat.jpg',
        'method': 'GET',
        'xhrFields': {
            'responseType': _0x3084('‮3d', 'kAHO')
        }
    })[_0x3084('‮3e', 'AMID')](function(_0xf6e0bc) {
        var _0x200315 = _0x1fea60[_0x3084('‫3f', ']XO^')](str2Ab, _0x1fea60[_0x3084('‫40', '@MU(')](_0x1fea60[_0x3084('‮41', '[r3y')](randStr, 0x8), '**'));
        var _0x3b8510 = str2Ab(_0x1fea60[_0x3084('‫42', 'kAHO')](abToBase64, _0x31d96a));
        var _0x3d2c7d = _0x1fea60[_0x3084('‫43', '0uTG')](concatAb, _0xf6e0bc, _0x200315, _0x3b8510);
        _0x1fea60[_0x3084('‮44', 'AMID')](downloadFile, _0x1fea60[_0x3084('‮45', '*g@m')](_0x5f7583, _0x1fea60[_0x3084('‮46', 'Yj]*')]), _0x3d2c7d);
    });
}
async function decrypt(_0x29fdf9) {
    var _0x29b809 = {
        'FvLkL': _0x3084('‫47', ']XO^'),
        'iLnOf': function(_0x57bddc, _0x2d5e63) {
            return _0x57bddc(_0x2d5e63);
        },
        'HtQOw': _0x3084('‫48', 'L#9('),
        'iWKJP': function(_0x36f9e2, _0x179969) {
            return _0x36f9e2(_0x179969);
        },
        'qvFkR': _0x3084('‮49', 'Ba8C')
    };
    var _0xc47ad3 = _0x29b809[_0x3084('‮4a', 'gbdg')][_0x3084('‫4b', 'f#i@')]('|'),
        _0x55b8b8 = 0x0;
    while (!![]) {
        switch (_0xc47ad3[_0x55b8b8++]) {
            case '0':
                var _0x5dbbf8 = ab2Str(_0x4b0025);
                continue;
            case '1':
                var _0x1a45f4 = _0x29b809[_0x3084('‫4c', '%V[U')](getFileName, _0x33b422[_0x3084('‫4d', 'WErh')]);
                continue;
            case '2':
                _0x382ee4 = CryptoJS[_0x3084('‮4e', 'Ugcw')][_0x3084('‮4f', '0uTG')][_0x3084('‫50', 'O(uL')](_0x382ee4[_0x3084('‫51', '58bt')](0x10, '0'));
                continue;
            case '3':
                var _0x26c1c6 = CryptoJS[_0x3084('‮4e', 'Ugcw')]['Hex'][_0x3084('‫52', '58bt')](_0x5dbbf8[_0x3084('‫53', 'sCFv')](_0x1527a4 + 0x4, -0x1a));
                continue;
            case '4':
                var _0x33b422 = _0x29fdf9[_0x3084('‫54', 'dDml')][_0x3084('‮55', '(gTk')][_0x3084('‮56', 'CynS')](0x0);
                continue;
            case '5':
                var _0x4d2217 = _0x5dbbf8[_0x3084('‮57', 'Ba8C')](-0x1a);
                continue;
            case '6':
                _0xe8b43c = CryptoJS[_0x3084('‮58', 'WErh')]['Utf8']['parse'](_0xe8b43c[_0x3084('‮59', 'f#i@')](0x10, '0'));
                continue;
            case '7':
                var _0x1527a4 = _0x5dbbf8['indexOf'](_0x29b809['HtQOw']);
                continue;
            case '8':
                var _0x382ee4 = CryptoJS['enc'][_0x3084('‮5a', 'Hw2W')][_0x3084('‮5b', 'AMID')](CryptoJS[_0x3084('‮4e', 'Ugcw')][_0x3084('‫5c', 'OaSd')][_0x3084('‮5d', 'B#(0')](_0x4d2217));
                continue;
            case '9':
                var _0x7851ca = CryptoJS[_0x3084('‮5e', 'cLOz')][_0x3084('‫5f', 'iQj4')][_0x3084('‫60', 'AOZ*')](_0x26c1c6);
                continue;
            case '10':
                var _0xe8b43c = CryptoJS[_0x3084('‮61', '(SGn')]['Utf8']['stringify'](CryptoJS['enc'][_0x3084('‮62', 'Ugcw')][_0x3084('‫63', 'ZWyl')](_0x5dbbf8[_0x3084('‮64', '[r3y')](0x4, _0x1527a4)));
                continue;
            case '11':
                var _0x4b0025 = await _0x33b422[_0x3084('‮65', 'O(uL')]();
                continue;
            case '12':
                decryptedAb = _0x29b809['iWKJP'](str2Ab, _0x39bbd6);
                continue;
            case '13':
                _0x39bbd6 = _0x39bbd6['toString'](CryptoJS[_0x3084('‮66', 'dVIg')][_0x3084('‫67', 'Yj]*')]);
                continue;
            case '14':
                downloadFile(_0x1a45f4 + _0x29b809[_0x3084('‮68', 'L#9(')], decryptedAb);
                continue;
            case '15':
                var _0x39bbd6 = CryptoJS[_0x3084('‮69', '@MU(')][_0x3084('‮6a', 'OaSd')](_0x7851ca, _0xe8b43c, {
                    'iv': _0x382ee4,
                    'mode': CryptoJS[_0x3084('‫6b', 'PZ)Q')]['CBC'],
                    'padding': CryptoJS[_0x3084('‫6c', '[r3y')][_0x3084('‮6d', 'O(uL')]
                });
                continue;
        }
        break;
    }
};
_0xodA = 'jsjiami.com.v6';